#!/bin/bash

sbatch submit_c_01.slurm
sbatch submit_c_02.slurm
